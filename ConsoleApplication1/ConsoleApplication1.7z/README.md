# fuzzy
Students simple fuzzy sets and calculus project
