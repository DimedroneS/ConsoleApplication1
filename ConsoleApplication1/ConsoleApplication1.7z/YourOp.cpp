#include "YourOp.hpp"

AlphaLevelFuzzy YourOp::run() {
    return getResult();
};